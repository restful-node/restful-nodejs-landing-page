# learning_wordpress_46
https://app.pluralsight.com/player?course=wordpress-custom-theme-development&amp;author=susan-simkins&amp;name=wordpress-custom-theme-development-m1&amp;clip=1&amp;mode=live
